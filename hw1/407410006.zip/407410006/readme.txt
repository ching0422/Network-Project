姓名:鄧晴
學號:407410006
環境:linux vscode
github:

執行方式:
1. make
2. sudo ./hw1
3. 瀏覽器開啟localhost:8080


參考資料:
https://github.com/PacktPublishing/Hands-On-Network-Programming-with-C
http://ajing-notebook.blogspot.com/2019/01/c-socket-server.html
https://b8807053.pixnet.net/blog/post/3611338
https://fred-zone.blogspot.com/2007/09/http-web-server.html